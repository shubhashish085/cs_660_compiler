public class Math {

    static double abs(double a) { return 0.00; }

    static float abs(float a) {	return 0.00F; }

    static int abs(int a) { return 0; }

    static long abs(long a) { return 0L; }

    static double acos(double a) { return 0.00; }
    
    static double asin(double a) { return 0.00; }

    static double atan(double a) { return 0.00; }

    static double atan2(double y, double x) { return 0.00; }
    
    static double cbrt(double a) { return 0.00; }
    
    static double ceil(double a) { return 0.00; }

    static double copySign(double magnitude, double sign) { return 0.00; }
    
    static float copySign(float magnitude, float sign) { return 0.00F; }

    static double cos(double a) { return 0.00; }
    
    static double cosh(double x) { return 0.00; }
    
    static double exp(double a) { return 0.00; }
    
    static double expm1(double x) { return 0.00;; }
    
    static double floor(double a) { return 0.00; }
    
    static int getExponent(double d) { return 0; }

    static int getExponent(float f) { return 0; }

    static double hypot(double x, double y) { return 0.00; }
    
    static double IEEEremainder(double f1, double f2) { return 0.00; }
    
    static double log(double a) { return 0.00; }

    static double log10(double a) { return 0.00; }

    static double log1p(double x) { return 0.00; }

    static double max(double a, double b) { return 0.00; }

    static float max(float a, float b) { return 0.00F; }
    
    static int max(int a, int b) { return 0; }

    static long max(long a, long b) { return 0L; }

    static double min(double a, double b) { return 0.00; }

    static float min(float a, float b) { return 0.00F; }

    static int min(int a, int b) { return 0; }

    static long min(long a, long b) { return 0L; }

    static double nextAfter(double start, double direction) { return 0.00; }

    static float nextAfter(float start, double direction) { return 0.00F; }

    static double nextUp(double d) { return 0.00; }

    static float nextUp(float f) { return 0.00F; }

    static double pow(double a, double b) { return 0.00; }

    static double random() { return 0.00; }

    static double rint(double a) { return 0.00; }

    static long round(double a) { return 0L; }

    static int round(float a) { return 0; }

    static double scalb(double d, int scaleFactor) { return 0.00; }
    
    static float scalb(float f, int scaleFactor) { return 0.00F; }

    static double signum(double d) { return 0.00; }

    static float signum(float f) { return 0.00F; }

    static double sin(double a) { return 0.00; }

    static double sinh(double x) { return 0.00; }

    static double sqrt(double a) { return 0.00; }

    static double tan(double a) { return 0.00; }
    
    static double tanh(double x) { return 0.00; }

    static double toDegrees(double angrad) { return 0.00; }

    static double toRadians(double angdeg) { return 0.00; }

    static double ulp(double d) { return 0.00; }
    
    static float ulp(float f) { return 0.00F; }
}