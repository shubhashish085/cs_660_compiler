package Utilities;

public class SymbolTable {
    // Intentionally left blank - content will appear in phase 3 handout
    public SymbolTable() {
    }
    
    public SymbolTable(SymbolTable parent) {
    }

    public String toString() { 
        return "{}"; 
    }
}