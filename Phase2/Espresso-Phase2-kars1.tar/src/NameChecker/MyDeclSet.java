package NameChecker;

import Utilities.Visitor;
import Utilities.SymbolTable;

public class MyDeclSet  extends Visitor {
    // Intentionally left blank - content will appear in phase 3 handout
    public MyDeclSet(SymbolTable classTable, boolean debug) { 
    }
}
    
