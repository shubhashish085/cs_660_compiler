public class Strings {
    public static String toString(int x) { }
}