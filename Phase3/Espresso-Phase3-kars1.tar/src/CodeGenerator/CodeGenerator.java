package CodeGenerator;

import AST.*;

public class CodeGenerator {
    public void generate(Compilation program, boolean debug) {
	// Intentionally left blank
    }
}